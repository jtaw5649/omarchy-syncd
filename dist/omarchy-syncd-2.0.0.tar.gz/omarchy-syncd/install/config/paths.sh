#!/usr/bin/env bash

set -euo pipefail

mkdir -p "$HOME/.config/omarchy-syncd"
log_info "Ensured config directory at $HOME/.config/omarchy-syncd"
